# Clear variables
rm(list = ls())

library(readxl)
library(openxlsx)
library(parallel)
source("Functions/missingPattern.R")
source("Functions/NRMS.R")
source("Functions/AE.R")
source("ECLRMC.R")
source("process.R")



datasetName = "CNP"

# Path to incomplete datasets
incomplete_dir = paste0("Datasets/Incomplete+Datasets/", datasetName)
# Read complete dataset
complete_path <- paste0("Datasets/Original+Datasets/",datasetName,".xlsx");
complete_ds <- read_excel(complete_path, col_names=FALSE)
files = list.files(path=incomplete_dir)
nrmsList = c();
i=0

print(sapply(files, process))
for(file in files)
  process(file)
  warnings()
